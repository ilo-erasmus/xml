package com.example.tomek.myapplication;


import android.annotation.SuppressLint;
import android.content.res.XmlResourceParser;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;


import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    private static String getStringFromInputStream(InputStream is) { //nie wnikać
                                                                //dla ciekawskich jednak opisuje
        BufferedReader br = null;
        StringBuilder sb = new StringBuilder(); //budowniczy i bufory

        String line;
        try {

            br = new BufferedReader(new InputStreamReader(is));
            while ((line = br.readLine()) != null) {        //pentla kręci sie i dodaje do budowniczego teskt do puki coś jest w buforze (tak wiem że br.readLine()!= null nie zawsze działa)
                sb.append(line);
            }

        } catch (IOException e) { // try catche
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return sb.toString();

    }
    protected ArrayAdapter adapter;
    @SuppressLint("ResourceType") // nie potrzebne ale kod bez ostrzerzeń musi być
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(this,getStringFromInputStream(getResources().openRawResource(R.xml.db)),Toast.LENGTH_LONG).show();//TYLKO DO TESTU DOSTĘPU
        // kilka następnych linijek to idiotyzm(przynajmniej by to pokazaćm, w perspektywie długofalowej się ok ) (moim zdaniem), ale mniejsza z tym
        ListView lista = findViewById(R.id.lista);
        List<String> initialList = new ArrayList<String>();
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, initialList);
        lista.setAdapter(adapter);
        Button przy = findViewById(R.id.button);
        przy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                XmlResourceParser xml = getResources().getXml(R.xml.db);
                int gdzieja = 0;
                try {
                    gdzieja = xml.getEventType();
                    while (gdzieja != XmlPullParser.END_DOCUMENT) {
                        String a = xml.getName();
                        String b;
                        if (a != null) {
                            if (a.equals("imiona")) {
                                gdzieja = xml.next();
                                a = xml.getName();
                                boolean end=true;
                                while (gdzieja != XmlPullParser.END_DOCUMENT &&end) {

                                    a = xml.getName();
                                    b = xml.getText();
                                    if (a == null&&b!=null) {// Tutaj xml tag ma nazwe null ale za to ma zawartość
                                            adapter.add(b);
                                    }

                                    if(a!=null) {
                                        if (a.equals("imiona")) {
                                            end = false;
                                        }
                                    }
                                    gdzieja =  xml.next();
                                }
                            }
                        }
                        gdzieja = xml.next();
                    }
                    } catch (XmlPullParserException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                adapter.notifyDataSetChanged();
            }
        });


    }    }

